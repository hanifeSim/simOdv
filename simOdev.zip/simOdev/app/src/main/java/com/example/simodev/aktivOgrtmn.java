package com.example.simodev;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class aktivOgrtmn extends AppCompatActivity {
    Intent intent, intentSon;
    Bundle bundle, bundleSon;
    Button btnGerid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aktiv_ogrtmn);
        intent = getIntent();
        bundle = intent.getExtras();
        btnGerid = findViewById(R.id.btnGerid);

    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Bundle bundleSon=data.getExtras();
    }

    public void onClick(View view) {

        intentSon= new Intent();


        Intent intent = intentSon.putExtras(bundleSon);
        setResult(RESULT_OK, intentSon);
        finish();

    }
}
