package com.example.simodev;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Intent intent;
    Bundle bundle;
    EditText isim;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }



    public void onClick(View view) {

        isim = (EditText)findViewById(R.id.etIsim);

        bundle = new Bundle();
        bundle.get("isim");

        intent= new Intent (this, aktivOgrenci.class);
        intent.putExtras(bundle);

        startActivityForResult(intent, 1);

        if (view.getId()==R.id.btnGndr)
        {
            intent = new Intent(this,aktivOgrenci.class);
            intent.putExtras(bundle);
            startActivityForResult(intent,1);
        }
        else
        {
            intent = new Intent(this,aktivOgrtmn.class);
            intent.putExtras(bundle);
            startActivityForResult(intent,2);
        }


    }

}
