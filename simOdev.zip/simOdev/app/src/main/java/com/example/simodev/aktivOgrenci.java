package com.example.simodev;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class aktivOgrenci extends AppCompatActivity {
    Intent intent, intentSon;
    Bundle bundle, bundleSon;
    String isim;
    TextView tvIsim;
    Button btnGeri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aktiv_ogrenci);
        tvIsim = findViewById(R.id.tvIsim);
        btnGeri = findViewById(R.id.btnGerid);


        intent = getIntent();
        bundle = intent.getExtras();
        isim = bundle.getString("isim");
        //setViews(isim);

    }

   // private void setViews(String isim) {
      //  tvIsim.setText(isim);
    //}

    public void onClick(View view) {
        intentSon= new Intent();
        bundleSon.putString("isim",isim.toString());
        Intent intent = intentSon.putExtras(bundleSon);
        setResult(RESULT_OK, intentSon);
        finish();
    }
}
